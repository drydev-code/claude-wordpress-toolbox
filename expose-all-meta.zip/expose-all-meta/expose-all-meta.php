<?php
/**
 * Plugin Name: Expose All Meta to REST API
 * Description: Exposes all post meta to the REST API for wp-content-sync.
 * Version: 1.1.0
 * Author: WP Content Sync
 */

if (!defined('ABSPATH')) exit;

add_action('rest_api_init', function() {
    register_rest_field(
        ['post', 'page'],
        'all_meta',
        [
            'get_callback' => function($post) {
                $meta = get_post_meta($post['id']);
                $result = [];
                foreach ($meta as $key => $values) {
                    if (strpos($key, '_edit_') === 0 || strpos($key, '_wp_') === 0) continue;
                    $result[$key] = count($values) === 1 ? maybe_unserialize($values[0]) : array_map('maybe_unserialize', $values);
                }
                return $result;
            },
            'update_callback' => function($value, $post) {
                if (!is_array($value)) return;
                foreach ($value as $key => $val) {
                    update_post_meta($post->ID, $key, $val);
                }
            },
            'schema' => ['type' => 'object']
        ]
    );
});

add_filter('wp_is_application_passwords_available', '__return_true');
